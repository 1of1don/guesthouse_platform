// Puts four sample guesthouses into Firestore so the app has something to show.
// Run it from the project folder:
//   node --env-file=.env scripts/seed.mjs      (Node 20.6 or newer)
// It writes with fixed ids, so running it twice just overwrites, no duplicates.
import { initializeApp } from 'firebase/app';
import { collection, doc, getDocs, getFirestore, serverTimestamp, setDoc } from 'firebase/firestore';

const env = process.env;
if (!env.EXPO_PUBLIC_FIREBASE_API_KEY || !env.EXPO_PUBLIC_FIREBASE_PROJECT_ID) {
  console.error('No Firebase keys found. Make sure .env exists in this folder and run the command from here.');
  process.exit(1);
}

const app = initializeApp({
  apiKey: env.EXPO_PUBLIC_FIREBASE_API_KEY,
  authDomain: env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: env.EXPO_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: env.EXPO_PUBLIC_FIREBASE_APP_ID,
});
const db = getFirestore(app);
const pic = (seed) => `https://picsum.photos/seed/${seed}/900/600`;

const base = { country: 'Botswana', ratingSum: 0, ratingCount: 0, averageRating: 0 };
const guesthouses = [
  { id: 'riverside', name: 'Riverside Guesthouse', city: 'Gaborone', pricePerNight: 650,
    description: 'A cozy riverside stay with garden views, walking distance to the CBD.',
    amenities: ['Wifi', 'Parking', 'Pool', 'Breakfast'], latitude: -24.6282, longitude: 25.9231,
    contactDetails: '+267 71 234 567', logoUrl: pic('riverside-logo'),
    galleryUrls: [pic('riverside1'), pic('riverside2'), pic('riverside3')] },
  { id: 'acacia', name: 'Acacia Lodge', city: 'Francistown', pricePerNight: 480,
    description: 'Quiet lodge under old acacia trees, close to the airport and the city centre.',
    amenities: ['Wifi', 'Parking', 'Breakfast'], latitude: -21.1699, longitude: 27.5084,
    contactDetails: '+267 72 345 678', logoUrl: pic('acacia-logo'),
    galleryUrls: [pic('acacia1'), pic('acacia2')] },
  { id: 'kalahari', name: 'Kalahari Rest Stop', city: 'Maun', pricePerNight: 720,
    description: 'Base for Okavango Delta trips, with a shaded courtyard and a campfire area.',
    amenities: ['Wifi', 'Pool', 'Bar', 'Airport shuttle'], latitude: -19.9833, longitude: 23.4167,
    contactDetails: '+267 73 456 789', logoUrl: pic('kalahari-logo'),
    galleryUrls: [pic('kalahari1'), pic('kalahari2'), pic('kalahari3')] },
  { id: 'desertrose', name: 'Desert Rose Inn', city: 'Ghanzi', pricePerNight: 390,
    description: 'Simple, clean rooms on the edge of town. Good stop on the Trans-Kalahari route.',
    amenities: ['Wifi', 'Parking'], latitude: -21.7, longitude: 21.65,
    contactDetails: '+267 74 567 890', logoUrl: pic('rose-logo'),
    galleryUrls: [pic('rose1')] },
];

try {
  for (const { id, ...rest } of guesthouses) {
    await setDoc(doc(db, 'guesthouses', id), { ...base, ...rest, createdAt: serverTimestamp() });
    console.log('wrote', id);
  }
  // Read it back so we know it really landed.
  const check = await getDocs(collection(db, 'guesthouses'));
  console.log(`Done. Firestore now holds ${check.size} guesthouse(s).`);
  process.exit(0);
} catch (e) {
  if (e.code === 'permission-denied') {
    console.error('\nFirestore blocked the write. Publish firestore.dev.rules (Firestore > Rules in the console), wait a minute, then run this again.');
  } else {
    console.error('\nSeeding failed:', e.code ?? e.message);
  }
  process.exit(1);
}
