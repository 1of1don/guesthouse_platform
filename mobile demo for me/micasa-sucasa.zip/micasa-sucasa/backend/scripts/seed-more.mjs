// Adds 10 more guesthouses (different cities, countries, prices and ratings),
// plus a few reviews each, so you can properly test search, sorting and currency.
//
//   node --env-file=.env scripts/seed-more.mjs            adds them next to what you have
//   node --env-file=.env scripts/seed-more.mjs --reset    deletes ALL guesthouses and ratings first
//
// Careful with --reset: if the web team has added real guesthouses, they go too.
import { initializeApp } from 'firebase/app';
import {
  collection, deleteDoc, doc, getDocs, getFirestore, setDoc, Timestamp,
} from 'firebase/firestore';

const env = process.env;
if (!env.EXPO_PUBLIC_FIREBASE_PROJECT_ID) {
  console.error('No Firebase keys found. Run this from the folder that has your .env file.');
  process.exit(1);
}

const app = initializeApp({
  apiKey: env.EXPO_PUBLIC_FIREBASE_API_KEY,
  authDomain: env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: env.EXPO_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: env.EXPO_PUBLIC_FIREBASE_APP_ID,
});
const db = getFirestore(app);

const photo = (name) => `https://picsum.photos/seed/${name}/900/600`;
const daysAgo = (n) => Timestamp.fromMillis(Date.now() - n * 86400000);
const reviewers = ['Naledi M.', 'Tumelo K.', 'Kabo S.', 'Neo P.', 'Lesego T.', 'Mpho R.'];

// reviews are [score, reviewer number, comment, days ago]
const guesthouses = [
  { id: 'savanna-sunset-lodge', name: 'Savanna Sunset Lodge', city: 'Kasane', country: 'Botswana',
    pricePerNight: 890, latitude: -17.8101, longitude: 25.1514, phone: '+267 625 0101', photos: 4, added: 3,
    amenities: ['Wifi', 'Pool', 'Bar', 'River cruises', 'Breakfast'],
    description: 'Thatched chalets near the Chobe River. Elephants walk past the deck most evenings.',
    reviews: [[5, 0, 'Woke up to elephants at the water. Staff were brilliant.', 6],
              [5, 1, 'Pricey but worth every pula.', 14],
              [4, 2, 'Great views. The wifi is slow.', 21],
              [5, 3, 'Best stay of our whole trip.', 30]] },
  { id: 'palapye-stopover', name: 'Palapye Stopover Guesthouse', city: 'Palapye', country: 'Botswana',
    pricePerNight: 350, latitude: -22.546, longitude: 27.125, phone: '+267 492 0202', photos: 2, added: 9,
    amenities: ['Wifi', 'Parking', 'Air conditioning'],
    description: 'Clean, quiet rooms ten minutes from BIUST. Popular with visiting lecturers.',
    reviews: [[4, 1, 'Quiet and clean, easy parking.', 8],
              [3, 4, 'Fine for one night. Walls are thin.', 25],
              [4, 5, 'Good value near the university.', 40]] },
  { id: 'serowe-heritage-house', name: 'Serowe Heritage House', city: 'Serowe', country: 'Botswana',
    pricePerNight: 420, latitude: -22.3876, longitude: 26.7108, phone: '+267 463 0303', photos: 3, added: 20,
    amenities: ['Wifi', 'Parking', 'Garden', 'Breakfast'],
    description: 'A restored family home with a shaded garden, close to the Khama Rhino Sanctuary.',
    reviews: [[5, 2, 'The garden breakfast was the highlight.', 10],
              [4, 0, 'Lovely hosts.', 33]] },
  { id: 'lobatse-hillside-rest', name: 'Lobatse Hillside Rest', city: 'Lobatse', country: 'Botswana',
    pricePerNight: 280, latitude: -25.224, longitude: 25.676, phone: '+267 533 0404', photos: 1, added: 45,
    amenities: ['Parking'],
    description: 'Basic budget rooms on a hill above town. Bring your own towels.',
    reviews: [[3, 3, 'Cheap and basic, as described.', 12],
              [2, 4, 'Hot water was off the whole stay.', 28],
              [3, 5, 'OK for a night.', 50]] },
  { id: 'delta-view-bnb', name: 'Delta View B&B', city: 'Maun', country: 'Botswana',
    pricePerNight: 650, latitude: -19.9936, longitude: 23.4181, phone: '+267 686 0505', photos: 3, added: 1,
    amenities: ['Wifi', 'Breakfast', 'Airport shuttle'],
    description: 'Brand new B&B with a rooftop terrace. No reviews yet. Same price as Riverside, to test sort ties.',
    reviews: [] },
  { id: 'gaborone-city-centre-suites', name: 'Gaborone City Centre Suites', city: 'Gaborone', country: 'Botswana',
    pricePerNight: 1150, latitude: -24.6545, longitude: 25.9086, phone: '+267 390 0606', photos: 5, added: 60,
    amenities: ['Wifi', 'Pool', 'Gym', 'Parking', 'Breakfast', 'Air conditioning'],
    description: 'Serviced suites next to the main mall, with a gym and a rooftop pool.',
    reviews: [[5, 0, 'Spotless and very central.', 5],
              [4, 1, 'Great rooms, noisy street.', 11],
              [5, 2, 'Perfect for a work trip.', 19],
              [4, 3, 'Breakfast could be better.', 27],
              [4, 4, 'Would stay again.', 44]] },
  { id: 'windhoek-karoo-inn', name: 'Windhoek Karoo Inn', city: 'Windhoek', country: 'Namibia',
    pricePerNight: 780, latitude: -22.5609, longitude: 17.0658, phone: '+264 61 000 0707', photos: 3, added: 15,
    amenities: ['Wifi', 'Parking', 'Bar', 'Braai area'],
    description: 'Family-run inn with a braai area, ten minutes from the city centre.',
    reviews: [[4, 2, 'Friendly, great braai.', 9],
              [4, 5, 'Comfortable beds.', 22]] },
  { id: 'livingstone-falls-backpackers', name: 'Livingstone Falls Backpackers', city: 'Livingstone', country: 'Zambia',
    pricePerNight: 310, latitude: -17.8419, longitude: 25.8544, phone: '+260 213 000 808', photos: 4, added: 7,
    amenities: ['Wifi', 'Pool', 'Bar', 'Dorm rooms'],
    description: 'Lively backpackers a short ride from Victoria Falls, with a pool and a bar.',
    reviews: [[4, 0, 'Fun crowd, easy to book trips.', 4],
              [5, 3, 'Loved the pool.', 16],
              [3, 1, 'Dorm was cramped.', 38]] },
  { id: 'jozi-garden-guest-house', name: 'Jozi Garden Guest House', city: 'Johannesburg', country: 'South Africa',
    pricePerNight: 950, latitude: -26.2041, longitude: 28.0473, phone: '+27 11 000 0909', photos: 3, added: 33,
    amenities: ['Wifi', 'Pool', 'Parking', 'Breakfast', 'Security'],
    description: 'Leafy guest house in a gated street, ideal for a night before an early flight.',
    reviews: [[4, 4, 'Safe and calm.', 13],
              [5, 5, 'Excellent breakfast.', 29]] },
  { id: 'mogoditshane-family-cottages', name: 'The Old Mogoditshane Family Guesthouse and Garden Cottages',
    city: 'Mogoditshane', country: 'Botswana',
    pricePerNight: 520, latitude: -24.6272, longitude: 25.8643, phone: '+267 391 1010', photos: 1, added: 2,
    amenities: ['Wifi', 'Garden'],
    description: 'A very long name on purpose, to check that cards and headers cope with wrapping text.',
    reviews: [[2, 2, 'Nice garden but we waited an hour at check-in.', 3]] },
];

// If asked, wipe the old data first.
async function wipe(name) {
  const snap = await getDocs(collection(db, name));
  for (const d of snap.docs) await deleteDoc(d.ref);
  console.log(`deleted ${snap.size} from ${name}`);
}

try {
  if (process.argv.includes('--reset')) {
    await wipe('ratings');
    await wipe('guesthouses');
  }

  for (const g of guesthouses) {
    // Work out the totals from the reviews so they always match.
    const sum = g.reviews.reduce((total, r) => total + r[0], 0);
    const count = g.reviews.length;

    await setDoc(doc(db, 'guesthouses', g.id), {
      name: g.name, description: g.description, city: g.city, country: g.country,
      contactDetails: g.phone, pricePerNight: g.pricePerNight,
      latitude: g.latitude, longitude: g.longitude, amenities: g.amenities,
      logoUrl: photo(`${g.id}-logo`),
      galleryUrls: Array.from({ length: g.photos }, (_, i) => photo(`${g.id}-${i + 1}`)),
      ratingSum: sum, ratingCount: count, averageRating: count ? sum / count : 0,
      createdAt: daysAgo(g.added),
    });

    for (const [score, who, comment, ago] of g.reviews) {
      const customerId = `seed_${who}`;
      await setDoc(doc(db, 'ratings', `${g.id}_${customerId}`), {
        guesthouseId: g.id, customerId, customerName: reviewers[who],
        score, comment, createdAt: daysAgo(ago),
      });
    }
    console.log('wrote', g.id, count ? `(${count} reviews)` : '(no reviews)');
  }

  const saved = await getDocs(collection(db, 'guesthouses'));
  console.log(`Done. Firestore now has ${saved.size} guesthouse(s).`);
  process.exit(0);
} catch (e) {
  if (e.code === 'permission-denied') {
    console.error('\nFirestore blocked the write. Publish firestore.dev.rules in the console, wait a minute, and try again.');
  } else {
    console.error('\nSeeding failed:', e.code ?? e.message);
  }
  process.exit(1);
}
